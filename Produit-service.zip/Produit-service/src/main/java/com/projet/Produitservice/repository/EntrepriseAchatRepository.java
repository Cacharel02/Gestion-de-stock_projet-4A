package com.projet.Produitservice.repository;

import com.projet.Produitservice.model.EntrepriseAchat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EntrepriseAchatRepository extends JpaRepository<EntrepriseAchat,Long> {
    List<EntrepriseAchat> findByEntreprise_Id(Long id);

}
