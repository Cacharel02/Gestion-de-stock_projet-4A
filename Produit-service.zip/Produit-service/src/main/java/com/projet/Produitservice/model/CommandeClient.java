package com.projet.Produitservice.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "commande_client")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CommandeClient {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String numero;
    private boolean etat; //etat devient true lorsque la commande est passée
    @OneToMany(cascade = CascadeType.ALL)
    private List<LigneCommandeClient> lignesCmdClient;
    @ManyToOne
    @JoinColumn(name = "client_id")
    private Client client;
}
