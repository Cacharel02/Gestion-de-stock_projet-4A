package com.projet.Produitservice.service;

import com.projet.Produitservice.model.Entreprise;
import com.projet.Produitservice.model.Stock;
import com.projet.Produitservice.repository.StockRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@RequiredArgsConstructor
public class StockServiceImpl implements StockService{

    private final StockRepository stockRepository;
    private final WebClient webClient;

    public Stock creerStock(String skuCode, Long id){
        Entreprise entreprise = webClient.get()
                .uri("http://localhost:8080/entreprises/"+id)
                .retrieve()
                .bodyToMono(Entreprise.class)
                .block();

        Stock stock = new Stock();
        stock.setQuantite(0);
        stock.setSkuCode(skuCode);
        stock.setEntreprise(entreprise);
        return stockRepository.save(stock);
    }
    @Transactional(readOnly = true)
    public boolean estEnStock(String skuCode){
        return stockRepository.findBySkuCode(skuCode).isPresent();
    }

    public Stock mettreEnStock(Long id, String skuCode,int quantite){
        return stockRepository.findBySkuCodeAndEntreprise_Id(skuCode,id)
                .map(s -> {
                    s.setQuantite(s.getQuantite()+quantite);
                    return stockRepository.save(s);
                }).orElseThrow(()->new RuntimeException("Le stock n'existe pas ! Veuillez le créer au préalable"));
        /*return stockRepository.findBySkuCode(skuCode)
                .filter(stock->stock.getEntreprise().getId()==id)
                .map(s -> {
                    s.setQuantite(s.getQuantite()+quantite);
                    return stockRepository.save(s);
                }).orElseThrow(()->new RuntimeException("Le stock n'existe pas ! Veuillez le créer au préalable"));*/
    }

    @Override
    public Stock retirerDeStock(String skuCode, int quantite, Long id) {
        Entreprise entreprise = webClient.get()
                .uri("http://localhost:8080/entreprises/"+id)
                .retrieve()
                .bodyToMono(Entreprise.class)
                .block();

        return stockRepository.findBySkuCodeLikeAndEntreprise_Id(skuCode,id)
                .map(s -> {
                    s.setQuantite(s.getQuantite()-quantite);
                    return stockRepository.save(s);
                }).orElseThrow(()->new RuntimeException("Le stock n'existe pas ! Veuillez le créer au préalable"));

    }

    @Override
    public Integer getQuantite(Long id, String skuCode) {
        return stockRepository.findBySkuCodeAndEntreprise_Id(skuCode,id).get().getQuantite();
    }


}
