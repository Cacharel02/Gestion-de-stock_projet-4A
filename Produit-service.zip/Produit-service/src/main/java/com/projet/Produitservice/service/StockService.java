package com.projet.Produitservice.service;

import com.projet.Produitservice.model.Stock;

public interface StockService {

    public Stock creerStock(String skuCode, Long id);
    public boolean estEnStock(String skuCode);
    public Stock mettreEnStock(Long id, String skuCode, int quantite);
    public Stock retirerDeStock(String skuCode, int quantite, Long id);
    public Integer getQuantite(Long id, String skuCode);
}
