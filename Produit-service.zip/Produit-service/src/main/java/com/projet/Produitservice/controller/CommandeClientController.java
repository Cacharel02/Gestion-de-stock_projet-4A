package com.projet.Produitservice.controller;


import com.projet.Produitservice.model.CommandeClient;
import com.projet.Produitservice.model.LigneCommandeClient;
import com.projet.Produitservice.service.CommandeClientService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin("*")
@RestController
@RequiredArgsConstructor
@RequestMapping("/commandeClient")
public class CommandeClientController {


    private final CommandeClientService commandeClientService;

    /*@PostMapping
    public String clientCommander(@RequestBody CommandeClientRequest commandeClientRequest){
        commandeClientService.clientCommander(commandeClientRequest);
        return "Commande passée avec succès !";
    }*/

    @PostMapping("/creerCmd/{id}")
    public CommandeClient clientCommander(@PathVariable Long id){
        return commandeClientService.clientCommander(id);
    }
    @PostMapping("/ajouterligne/{id}")
    public String ajouterLigne(@PathVariable Long id, @RequestBody LigneCommandeClient ligne){
        return commandeClientService.ajouterLigne(id, ligne);
    }
    @GetMapping("/getCommandes/{id}")
    public List<CommandeClient> getCommandes(@PathVariable Long id){
        return commandeClientService.getCommandes(id);
    }
    @GetMapping("/getLignes/{numero}")
    public List<LigneCommandeClient> getLignes(@PathVariable String numero){
        return commandeClientService.getLignes(numero);
    }
    @GetMapping("/getId/{numero}")
    public Long getId(@PathVariable String numero){
        return commandeClientService.getId(numero);
    }
}
