package com.projet.Produitservice.service;

import com.projet.Produitservice.model.*;
import com.projet.Produitservice.repository.AdminRepository;
import com.projet.Produitservice.repository.EntrepriseRepository;
import lombok.RequiredArgsConstructor;
import org.hibernate.mapping.Any;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class EntrepriseService {

    private final EntrepriseRepository entrepriseRepository;
    private final WebClient webClient;


    public Entreprise creerEntreprise(Entreprise entreprise){
        Administrateur admin = webClient.post()
                        .uri("http://localhost:8080/admin/creer")
                        .retrieve()
                        .bodyToMono(Administrateur.class)
                        .block();

        entreprise.setAdministrateur(admin);
        return entrepriseRepository.save(entreprise);
    }

    public Entreprise get(Long id) {
        return entrepriseRepository.findById(id).get();
    }

    public Produit ajouterProduit(Long id, String skuCode, int prix){
        Fournisseur fournisseur = webClient.post()
                .uri("http://localhost:8080/fournisseurs/creer?skuCode="+skuCode+"&prix="+(prix-10))
                .retrieve()
                .bodyToMono(Fournisseur.class)
                .block();
        Stock stock = webClient.post()
                .uri("http://localhost:8080/services/stock/creer?idEntreprise="+id+"&skuCode="+skuCode)
                .retrieve()
                .bodyToMono(Stock.class)
                .block();
        Produit produit = webClient.post()
                .uri("http://localhost:8080/services/produit/creer?id="+id+"&skuCode="+skuCode+"&prix="+prix)
                .retrieve()
                .bodyToMono(Produit.class)
                .block();
        return produit;
    }


    public Entreprise getByAdmin(Long id){
        for(Entreprise e : entrepriseRepository.findAll()){
            if(e.getAdministrateur().getId() == id){
                return e;
            }
        }

        return null;
    }

    public Administrateur getAdmin(Long id){
        return entrepriseRepository.findById(id).get().getAdministrateur();
    }

    /*public List<Produit> getProduits(Long id){
        return entrepriseRepository.findById(id).get().getProduits();
    }*/

    public Long getId(Entreprise entreprise){

        for(Entreprise e : entrepriseRepository.findAll()){
            if(e.getNom() == entreprise.getNom() && e.getAdresse() == entreprise.getAdresse()){
                return e.getId();
            }
        }
        return null;
    }

    public void acheter(Long idEntreprise, String skuCode, int quantite){
        Fournisseur fournisseur = webClient.get()
                .uri("http://localhost:8080/fournisseurs/getBySkuCode/"+skuCode)
                .retrieve()
                .bodyToMono(Fournisseur.class)
                .block();
        //Entreprise entreprise= get(idEntreprise);
        if(get(idEntreprise).getFond()>=quantite*fournisseur.getPrix()){
            EntrepriseAchat entrepriseAchat = webClient.post()
                    .uri("http://localhost:8080/achat entreprise/acheter?idEntreprise="+idEntreprise+"&skuCode="+skuCode+"&quantite="+quantite)
                    .retrieve()
                    .bodyToMono(EntrepriseAchat.class)
                    .block();

            Stock stock = webClient.put()
                    .uri("http://localhost:8080/services/stock/mettre?idEntreprise="+idEntreprise+"&skuCode="+fournisseur.getSkuCode()+"&quantite="+quantite)
                    .retrieve()
                    .bodyToMono(Stock.class)
                    .block();
            Entreprise entreprise = entrepriseRepository.findById(idEntreprise)
                    .map(e->{
                        e.setFond(get(idEntreprise).getFond() - (quantite*fournisseur.getPrix()));
                        return entrepriseRepository.save(e);
                    }).get();
        }



    }

    public void setFond(Long id, int valeur){
        //get(id).setFond(valeur);
        Entreprise entreprise = entrepriseRepository.findById(id)
                .map(e->{
                    e.setFond(valeur+e.getFond());
                    return entrepriseRepository.save(e);
                }).get();
    }
}
