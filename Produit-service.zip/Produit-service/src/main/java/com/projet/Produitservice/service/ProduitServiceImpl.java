package com.projet.Produitservice.service;


import com.projet.Produitservice.model.Entreprise;
import com.projet.Produitservice.model.Produit;
import com.projet.Produitservice.repository.ProduitRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProduitServiceImpl implements ProduitService{

    private final ProduitRepository produitRepository;
    private final WebClient webClient;

    @Override
    public Produit creer(Long id, String skuCode,int prix) {
        Entreprise entreprise = webClient.get()
                .uri("http://localhost:8080/entreprises/"+id)
                .retrieve()
                .bodyToMono(Entreprise.class)
                .block();
        Produit produit = new Produit();
        produit.setPrix(prix);
        produit.setDescription(skuCode);
        produit.setSkuCode(skuCode);
        produit.setEntreprise(entreprise);
        return produitRepository.save(produit);
    }

    @Override
    public List<Produit> liste() {
        return produitRepository.findAll();
    }

    @Override
    public Produit modifier(Long id, Produit produit) {
        return produitRepository.findById(id)
                .map(p -> {
                    p.setPrix(produit.getPrix());
                    p.setSkuCode(produit.getSkuCode());
                    p.setDescription(produit.getDescription());
                    return produitRepository.save(p);
                }).orElseThrow(()->new RuntimeException("Produit non trouvé !"));
    }

    @Override
    public void supprimer(Long id) {
        produitRepository.deleteById(id);
    }

    @Override
    public Produit find(String skuCode) {
        return produitRepository.findBySkuCode(skuCode).get();
    }

    @Override
    public void delete(String skuCode) {
        produitRepository.deleteById(find(skuCode).getId());
    }

    @Override
    public List<Produit> getProduitByEntreprise(Long id) {
        return produitRepository.findByEntreprise_Id(id);
    }
    @Override
    public Long get(String skuCode, Long id){
        return produitRepository.findBySkuCodeAndEntreprise_Id(skuCode,id).get().getId();
    }



    /*@Override
    public String supprimer(String skuCode) {
        produitRepository.deleteBySkuCode(skuCode);
        return "Produit supprimé !";
    }*/
}
