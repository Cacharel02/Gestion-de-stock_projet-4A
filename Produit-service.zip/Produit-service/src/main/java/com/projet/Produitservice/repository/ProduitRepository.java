package com.projet.Produitservice.repository;

import com.projet.Produitservice.model.Produit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProduitRepository extends JpaRepository<Produit,Long> {
    Optional<Produit> findBySkuCodeAndEntreprise_Id(String skuCode, Long id);
    List<Produit> findByEntreprise_Id(Long id);

    Optional<Produit> findBySkuCode(String skuCode);
}
