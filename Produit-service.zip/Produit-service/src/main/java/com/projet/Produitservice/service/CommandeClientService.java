package com.projet.Produitservice.service;


import com.projet.Produitservice.model.Client;
import com.projet.Produitservice.model.CommandeClient;
import com.projet.Produitservice.model.LigneCommandeClient;
import com.projet.Produitservice.model.Produit;
import com.projet.Produitservice.repository.CommandeClientRepository;
import com.projet.Produitservice.repository.LigneCdmClientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class CommandeClientService {

    private final CommandeClientRepository commandeClientRepository;
    private final LigneCdmClientRepository ligneCdmClientRepository;
    private final WebClient webClient;

    public CommandeClient clientCommander(Long id){
        CommandeClient commandeClient = new CommandeClient();
        Client client = webClient.get()
                .uri("http://localhost:8080/clients/"+id)
                .retrieve()
                .bodyToMono(Client.class)
                .block();
        commandeClient.setClient(client);
        commandeClient.setNumero(UUID.randomUUID().toString());


        return commandeClientRepository.save(commandeClient);
    }



    private CommandeClient get(Long id){
        return commandeClientRepository.findById(id).get();
    }

    public String ajouterLigne(Long id, LigneCommandeClient ligne){
        CommandeClient commandeClient = get(id);
        ligneCdmClientRepository.save(ligne);
        commandeClient.getLignesCmdClient().add(ligne);
        return "";
    }

    public List<CommandeClient> getCommandes(Long id){
        return commandeClientRepository.findByClient_Id(id);
    }

    public List<LigneCommandeClient> getLignes(String numero){
        return commandeClientRepository.findByNumero(numero).get().getLignesCmdClient();
    }

    public Long getId (String numero){
        return commandeClientRepository.findByNumero(numero).get().getId();
    }

    public void passerCommande(Long id){
        CommandeClient commande = get(id);
        for(LigneCommandeClient ligne : commande.getLignesCmdClient()){

        }
    }
}
