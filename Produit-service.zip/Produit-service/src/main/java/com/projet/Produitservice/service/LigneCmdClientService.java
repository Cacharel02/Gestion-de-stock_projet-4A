package com.projet.Produitservice.service;

import com.projet.Produitservice.model.LigneCommandeClient;
import com.projet.Produitservice.repository.LigneCdmClientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LigneCmdClientService {

    private final LigneCdmClientRepository ligneCdmClientPRepository;

    public LigneCommandeClient creer(LigneCommandeClient ligne){

        return ligneCdmClientPRepository.save(ligne);
    }
}
