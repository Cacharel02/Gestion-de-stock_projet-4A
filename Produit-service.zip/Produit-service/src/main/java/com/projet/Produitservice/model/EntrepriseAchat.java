package com.projet.Produitservice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "Entreprise_achat")
@Getter
@Setter
@NoArgsConstructor
public class EntrepriseAchat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "entreprise_id_entreprise")
    private Entreprise entreprise;
    @OneToOne
    @JoinColumn(name = "fournisseur_id")
    private Fournisseur fournisseur;
    private Integer quantite;
    private Integer prixUnitaire;
}
