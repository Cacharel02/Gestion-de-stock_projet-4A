package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.Administrateur;
import com.projet.Produitservice.service.AdminService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("*")
@RestController
@RequestMapping("/admin")
@AllArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @PostMapping("/creer")
    public Administrateur creer(){
        return adminService.creer();
    }
    @GetMapping("/get/{id}")
    public Administrateur getById(@PathVariable Long id){
        return adminService.getById(id);
    }
    @GetMapping("/getAdminId/{codeAdmin}")
    public Long  getAdmin(@PathVariable String codeAdmin){

        return adminService.getAdmin(codeAdmin);
    }
    @GetMapping("getPassword/{id}")
    public String getPassword(@PathVariable Long id){
        return adminService.getPassword(id);
    }
}
