package com.projet.Produitservice.service;

import com.projet.Produitservice.model.Fournisseur;
import com.projet.Produitservice.repository.FournisseurRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

@Service
@RequiredArgsConstructor
public class FournisseurService {

    private final FournisseurRepository fournisseurRepository;

    /*public Fournisseur creer(Fournisseur fournisseur){
        return fournisseurRepository.save(fournisseur);
    }*/

    public Fournisseur creer(String skuCode, int prix){
        Fournisseur fournisseur = new Fournisseur();
        fournisseur.setNom("Fournisseur de "+skuCode);
        fournisseur.setSkuCode(skuCode);
        fournisseur.setPrix(prix);
        return  fournisseurRepository.save(fournisseur);
    }

    public Fournisseur getByNom(String nom){
        return fournisseurRepository.findByNom(nom).get();
    }

    public Fournisseur getBySkuCode(String skuCode){
        return fournisseurRepository.findBySkuCode(skuCode).get();
    }
}
