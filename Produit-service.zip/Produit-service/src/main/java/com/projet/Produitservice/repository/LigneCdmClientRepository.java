package com.projet.Produitservice.repository;

import com.projet.Produitservice.model.LigneCommandeClient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LigneCdmClientRepository extends JpaRepository<LigneCommandeClient,Long> {
}
