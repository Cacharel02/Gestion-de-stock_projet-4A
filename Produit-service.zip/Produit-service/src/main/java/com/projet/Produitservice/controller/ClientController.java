package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.Client;
import com.projet.Produitservice.model.CommandeClient;
import com.projet.Produitservice.service.ClientService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/clients")
@AllArgsConstructor
public class ClientController {

    private final ClientService clientService;

    @PostMapping("/creer")
    public Client creer(@RequestBody Client client){
        return clientService.creer(client);
    }
    @GetMapping("/{id}")
    public Client getClientById(@PathVariable Long id){
        return clientService.getClientById(id);
    }
    @GetMapping("get/{codeClient}")
    public Long getClientId(@PathVariable String codeClient){
        return clientService.getClientId(codeClient);
    }


}
