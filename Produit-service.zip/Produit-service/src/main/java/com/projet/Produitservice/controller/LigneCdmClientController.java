package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.LigneCommandeClient;
import com.projet.Produitservice.service.LigneCmdClientService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("*")
@RestController
@RequestMapping("/ligne")
@AllArgsConstructor
public class LigneCdmClientController {

    private final LigneCmdClientService ligneService;

    @PostMapping("/creer/")
    public LigneCommandeClient creer(@RequestBody LigneCommandeClient ligne){
        return ligneService.creer(ligne);
    }

}
