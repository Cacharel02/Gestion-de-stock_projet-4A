package com.projet.Produitservice.service;

import com.projet.Produitservice.model.Client;
import com.projet.Produitservice.repository.ClientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ClientService {

    private final ClientRepository clientRepository;

    public Client creer(Client client){
        String codeClient = ""+ UUID.randomUUID().toString().substring(0,8);
        String password = ""+UUID.randomUUID().toString().substring(0,8);
        client.setCodeClient(codeClient);
        client.setPassword(password);
        return clientRepository.save(client);
    }

    public Client getClientById(Long id){
        return clientRepository.findById(id).get();
    }

    public Long getClientId(String codeClient){
        return clientRepository.findByCodeClient(codeClient).get().getId();
    }
}
