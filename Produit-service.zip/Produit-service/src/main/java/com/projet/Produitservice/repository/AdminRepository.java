package com.projet.Produitservice.repository;

import com.projet.Produitservice.model.Administrateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Administrateur,Long> {
}
