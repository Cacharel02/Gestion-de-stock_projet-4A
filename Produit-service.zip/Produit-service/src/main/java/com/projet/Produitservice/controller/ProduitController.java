package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.Produit;
import com.projet.Produitservice.service.ProduitService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/services/produit")
@AllArgsConstructor
public class ProduitController {
    private final ProduitService produitService;

    @PostMapping("/creer")
    public Produit creer(@RequestParam(value = "id") Long id, @RequestParam(value = "skuCode") String skuCode, @RequestParam(value = "prix") int prix){
        return produitService.creer(id,skuCode,prix);
    }

    @GetMapping("/liste")
    public List<Produit> liste(){
        return produitService.liste();
    }

    @PutMapping("/modifier/{id}")
    public Produit modifier(@PathVariable Long id, @RequestBody Produit produit){
        return produitService.modifier(id,produit);
    }

    @DeleteMapping("/supprimer/{id}")
    public void supprimer(@PathVariable Long id){
        produitService.supprimer(id);
    }

    @DeleteMapping("delete/{skuCode}")
    public void delete(@PathVariable String skuCode){
        produitService.delete(skuCode);

    }

    @GetMapping("/get/{skuCode}")
    public Long get(@PathVariable String skuCode){
        return produitService.find(skuCode).getId();
    }

    @GetMapping("/getproduit/{skuCode}")
    public Long getProduit(@PathVariable String skuCode, @RequestParam(value = "idEntreprise") Long idEntreprise){
        return produitService.get(skuCode,idEntreprise);
    }

    @GetMapping("/getProduits/{id}")
    public List<Produit> getProduitsByEntreprise(@PathVariable Long id){
        return produitService.getProduitByEntreprise(id);
    }
}
