package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.Administrateur;
import com.projet.Produitservice.model.Entreprise;
import com.projet.Produitservice.model.Produit;
import com.projet.Produitservice.service.EntrepriseService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/entreprises")
@AllArgsConstructor
public class EntrepriseController {

    private final EntrepriseService entrepriseService;
    @PostMapping("/creer")
    public Entreprise creer(@RequestBody Entreprise entreprise){
        return entrepriseService.creerEntreprise(entreprise);
    }

    @GetMapping("/{id}")
    public Entreprise get(@PathVariable Long id){
        return entrepriseService.get(id);
    }

    /*@PutMapping("/ajouterProduit/{id}")
    public void ajouter(@PathVariable Long id, @RequestBody Entreprise entreprise){
        entrepriseService.ajouterProduit(id,entreprise);
    }*/
    @GetMapping("/getByAdmin/{id}")
    public Entreprise getByAdmin(@PathVariable Long id){
        return entrepriseService.getByAdmin(id);
    }
    @GetMapping("/getAdmin/{id}")
    public Administrateur getAdmin(@PathVariable Long id){
        return entrepriseService.getAdmin(id);
    }
    /*@GetMapping("/getProduits/{id}")
    public List<Produit> getProduits(@PathVariable Long id){
        return entrepriseService.getProduits(id);
    }*/
    @GetMapping("/getId")
    public Long getTd(@RequestBody Entreprise entreprise){
        return entrepriseService.getId(entreprise);
    }

    @PostMapping("/ajouterProduit/{id}")
    public Produit ajouter(@PathVariable Long id, @RequestParam(value = "skuCode") String skuCode, @RequestParam(value = "prix") int prix){
        return entrepriseService.ajouterProduit(id,skuCode,prix);
    }
    @PostMapping("/acheter")
    public void acheter(@RequestParam(value = "idEntreprise") Long idEntreprise, @RequestParam(value = "skuCode") String skuCode, @RequestParam(value = "quantite") int quantite){
        entrepriseService.acheter(idEntreprise,skuCode,quantite);
    }
    @PutMapping("/setFond/{id}")
    public void setFond(@PathVariable Long id, @RequestParam(value = "value") int value){
        entrepriseService.setFond(id, value);
    }
}
