package com.projet.Produitservice.service;

import com.projet.Produitservice.model.Administrateur;
import com.projet.Produitservice.repository.AdminRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.AbstractMap;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final AdminRepository adminRepository;

    public Administrateur creer(){
        Administrateur admin = new Administrateur();
        String codeAdmin = ""+UUID.randomUUID().toString().substring(0,8);
        String password = ""+UUID.randomUUID().toString().substring(0,8);
        /*String codeAdmin = "bonjour";
        String password = "bonjour";*/
        admin.setCodeAdmin(codeAdmin);
        admin.setPassword(password);
        return adminRepository.save(admin);
    }

    public Administrateur getById(Long id){
        return adminRepository.findById(id).get();
    }

    /*public Administrateur getId(Administrateur administrateur){
        Administrateur admin = null;
        for(Administrateur a : adminRepository.findAll()){
            if(a.getCodeAdmin() == administrateur.getCodeAdmin()){
                admin = a;
            }
        }
        return admin;
    }*/
    public Long getAdmin(String codeAdmin){
        Administrateur a = null;
        for(Administrateur admin : adminRepository.findAll()){
            if(comparer(codeAdmin,admin.getCodeAdmin())){
                a = admin;
            }
        }
        return a.getId();
        //return administrateur.getCodeAdmin().charAt(1) ==  adminRepository.findAll().get(0).getCodeAdmin().charAt(1);
        //== adminRepository.findAll().get(0).getCodeAdmin().toString();
    }

    public boolean comparer(String a, String b){
        boolean r = true;
        for(int i = 0; i<a.length(); i++){
            if(a.charAt(i) != b.charAt(i)){
                r = false;
            }
        }
        return r;
    }

    public String getPassword(Long id){
        return adminRepository.findById(id).get().getPassword();
    }
}
