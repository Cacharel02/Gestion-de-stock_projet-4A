package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.Fournisseur;
import com.projet.Produitservice.service.FournisseurService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("*")
@RestController
@RequiredArgsConstructor
//@AllArgsConstructor
@RequestMapping("/fournisseurs")
public class FournisseurController {

    private final FournisseurService fournisseurService;

    @PostMapping("/creer")
    public Fournisseur creer(@RequestParam(value = "skuCode") String skuCode, @RequestParam(value = "prix") int prix){
        return fournisseurService.creer(skuCode, prix);
    }

    @GetMapping("/get/{nom}")
    public Fournisseur get(@PathVariable String nom){
        return fournisseurService.getByNom(nom);
    }

    @GetMapping("/getBySkuCode/{skuCode}")
    public Fournisseur getBySkuCode(@PathVariable String skuCode){
        return fournisseurService.getBySkuCode(skuCode);
    }
}
