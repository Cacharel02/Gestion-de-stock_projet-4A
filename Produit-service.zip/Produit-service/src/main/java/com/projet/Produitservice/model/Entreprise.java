package com.projet.Produitservice.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "ENTREPRISE")
@Getter
@Setter
@NoArgsConstructor
public class Entreprise {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_entreprise")
    private Long id;
    @Column(length = 50, name = "nom_entreprise")
    private String nom;
    @Column(length = 50)
    private String adresse;
    @Column(length = 50)
    private String email;
    /*@OneToMany(cascade = CascadeType.ALL)
    private List<Produit> produits;*/
    @OneToOne
    @JoinColumn(name = "administrateur_id")
    private Administrateur administrateur;
    private int fond;
}
