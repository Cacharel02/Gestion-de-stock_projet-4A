package com.projet.Produitservice.service;

import com.projet.Produitservice.ProduitServiceApplication;
import com.projet.Produitservice.model.Produit;

import java.util.List;

public interface ProduitService {

    Produit creer(Long id, String skuCode,int prix);
    List<Produit> liste();
    Produit modifier(Long id, Produit produit);
    void supprimer(Long id);
    Produit find(String skuCode);

    void delete(String skuCode);

    List<Produit> getProduitByEntreprise(Long id);

    Long get(String skuCode, Long id);

}
