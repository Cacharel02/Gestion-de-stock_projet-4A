package com.projet.Produitservice.service;

import com.projet.Produitservice.model.Administrateur;
import com.projet.Produitservice.model.Entreprise;
import com.projet.Produitservice.model.EntrepriseAchat;
import com.projet.Produitservice.model.Fournisseur;
import com.projet.Produitservice.repository.EntrepriseAchatRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EntrepriseAchatService {

    private final EntrepriseAchatRepository entrepriseAchatRepository;
    private final WebClient webClient;

    public void effectuerAchat(Long idEntreprise, String nomFournisseur,int quantite){
        EntrepriseAchat entrepriseAchat = new EntrepriseAchat();
        Entreprise entreprise = webClient.get()
                .uri("http://localhost:8080/entreprises/"+idEntreprise)
                .retrieve()
                .bodyToMono(Entreprise.class)
                .block();
        Fournisseur fournisseur = webClient.get()
                .uri("http://localhost:8080/fournisseurs/get/"+nomFournisseur)
                .retrieve()
                .bodyToMono(Fournisseur.class)
                .block();
        entrepriseAchat.setEntreprise(entreprise);
        entrepriseAchat.setFournisseur(fournisseur);
        entrepriseAchat.setQuantite(quantite);
        entrepriseAchat.setPrixUnitaire(fournisseur.getPrix());
        entrepriseAchatRepository.save(entrepriseAchat);
    }

    public List<EntrepriseAchat> getAchats (Long id){
        return entrepriseAchatRepository.findByEntreprise_Id(id);
    }

    public void acheter(Long idEntreprise, String skuCode, int quantite){
        EntrepriseAchat entrepriseAchat = new EntrepriseAchat();
        Entreprise entreprise = webClient.get()
                .uri("http://localhost:8080/entreprises/"+idEntreprise)
                .retrieve()
                .bodyToMono(Entreprise.class)
                .block();
        Fournisseur fournisseur = webClient.get()
                .uri("http://localhost:8080/fournisseurs/getBySkuCode/"+skuCode)
                .retrieve()
                .bodyToMono(Fournisseur.class)
                .block();
        entrepriseAchat.setEntreprise(entreprise);
        entrepriseAchat.setFournisseur(fournisseur);
        entrepriseAchat.setQuantite(quantite);
        entrepriseAchat.setPrixUnitaire(fournisseur.getPrix());
        entrepriseAchatRepository.save(entrepriseAchat);
    }
}
