package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.Stock;
import com.projet.Produitservice.service.StockService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("*")
@RestController
@RequiredArgsConstructor
//@AllArgsConstructor
@RequestMapping("/services/stock")
public class StockController {

    private final StockService stockService;

    @PostMapping("/creer")
    public Stock creerStock(@RequestParam(value="idEntreprise") Long id ,@RequestParam(value = "skuCode") String skuCode){
        return stockService.creerStock(skuCode, id);
    }

    @GetMapping("/{skuCode}")
    public boolean estEnStock(@PathVariable String skuCode){
        return stockService.estEnStock(skuCode);
    }


    @PutMapping("/mettre")
    public Stock mettreEnStock(@RequestParam(value = "idEntreprise") Long idEntreprise, @RequestParam(value = "skuCode") String skuCode, @RequestParam(value = "quantite") int quantite){
        return stockService.mettreEnStock(idEntreprise,skuCode,quantite);
    }

    @PutMapping("/enlever")
    public Stock retirerDeStock(@RequestParam(value = "skuCode") String skuCode, @RequestParam(value = "quantite") int quantite, @RequestParam(value = "idEntreprise") Long idEntreprise){
        return stockService.retirerDeStock(skuCode,quantite,idEntreprise);
    }
    @GetMapping("/getQte")
    public Integer getQte(@RequestParam(value = "idEntreprise") Long idEntreprise, @RequestParam(value = "skuCode") String skuCode){
        return  stockService.getQuantite(idEntreprise, skuCode);
    }

}
