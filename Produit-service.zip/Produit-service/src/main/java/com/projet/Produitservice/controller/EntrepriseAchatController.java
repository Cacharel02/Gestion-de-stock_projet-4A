package com.projet.Produitservice.controller;

import com.projet.Produitservice.model.Entreprise;
import com.projet.Produitservice.model.EntrepriseAchat;
import com.projet.Produitservice.service.EntrepriseAchatService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("*")
@RestController
@RequestMapping("/achat entreprise")
@AllArgsConstructor
public class EntrepriseAchatController {

    private final EntrepriseAchatService entrepriseAchatService;

    @PostMapping("/achat")
    public void effectuerAchat(@RequestParam(value = "idEntreprise") Long idEntreprise, @RequestParam(value = "nomFournisseur") String nomFournisseur, @RequestParam(value = "quantite") int quantite){
        entrepriseAchatService.effectuerAchat(idEntreprise,nomFournisseur,quantite);
    }

    @PostMapping("/acheter")
    public void acheter(@RequestParam(value = "idEntreprise") Long idEntreprise, @RequestParam(value="skuCode") String skuCode, @RequestParam(value = "quantite") int quantite){
        entrepriseAchatService.acheter(idEntreprise,skuCode,quantite);
    }
}
