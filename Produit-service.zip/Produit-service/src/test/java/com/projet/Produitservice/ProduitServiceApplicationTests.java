package com.projet.Produitservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProduitServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
